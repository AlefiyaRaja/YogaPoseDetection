# This is an AI Based Yoga based Detection System 

This project can be viewed[ Here](https://ephemeral-dodol-320707.netlify.app/).

## Snapshots of the website
<img align="center" width="100%" src="UY-1.png"> 
<img align="center" width="100%" src="UY-2.png">
<img align="center" width="100%" src="UY-3.png">
